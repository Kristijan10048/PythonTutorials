# Start up script for IronPythonConsole
import os
# Set properties for proper behaviour with PyDoc
os.environ['TERM'] = 'dumb'