
IronLab

Copyright (c) 2010 Joe Moorhouse

Available under the GNU Lesser General Public License
http://www.gnu.org/licenses/lgpl.html

Disclaimer:
THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Prerequisites:
IronLab uses .NET 4.0.
3D plotting uses DirectX9 (and accelerated 2D uses Direct2D).
For Windows 7 users some 3D features (e.g. thick 3D lines) require the latest DirectX End-User Runtime.
http://www.microsoft.com/en-us/download/details.aspx?id=35

Getting started:
Unzip, run IronPythonConsole.exe and try for example:

import numpy as np
import ironplot as ip
ip.plot(np.sin(np.arange(0, 10, 0.1)))

Examples are available in ironlab\Lib\site-packages\ironplot\Examples

*** In case of problems: ***
- If you download using Internet Explorer, make sure that the zip file in unblocked prior to extracting
(i.e. right click zip file -> Properties -> General -> Unblock, then unzip). 